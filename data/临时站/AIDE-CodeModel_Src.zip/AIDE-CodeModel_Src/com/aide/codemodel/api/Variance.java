package com.aide.codemodel.api;

public interface Variance {
   int INVARIANCE = 0;
   int BIVARIANCE = 1;
   int COVARIANCE = 2;
   int CONTRAVARIANCE = 3;
}
